﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    public class Dividir : Operacao
    {
        public void calcula(CalularValores calc)
        {
            if (calc.valor2 == 0) { CalularValores.setResultado(0); }
            else { CalularValores.setResultado(CalularValores.getResultado() / calc.valor2); }
        }
    }
}
