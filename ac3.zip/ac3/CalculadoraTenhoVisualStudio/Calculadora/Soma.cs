﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    public class Soma : Operacao
    {
        public void calcula (CalularValores calc)
        {
            CalularValores.setResultado(CalularValores.getResultado() + calc.valor2);
        }
    }
}
