﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class lblResulText : Form
    {
        public lblResulText()
        {
            InitializeComponent();
        }
        double? valor;
        string op;

        public void executarCalculo()
        {
            if (txtValores.Text != "")
            {
                valor = Convert.ToDouble(txtValores.Text);
                txtValores.Text = "";
                CalularValores o = new CalularValores(valor, op);
                if (op == "s")
                {
                    Soma b = new Soma();
                    b.calcula(o);
                }
                else if (op == "su")
                {
                    Subtracao b = new Subtracao();
                    b.calcula(o);
                }
                else if (op == "mu")
                {
                    Multiplicar b = new Multiplicar();
                    b.calcula(o);
                }
                else if (op == "di")
                {
                    Dividir b = new Dividir();
                    b.calcula(o);
                }
                lblResultado.Text = Convert.ToString(CalularValores.getResultado());
            }

        }


        private void btnSomar_Click(object sender, EventArgs e)
        {
            op = "s";
            executarCalculo();
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "0";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtValores.Text = txtValores.Text + "9";
        }

        private void btnPonto_Click(object sender, EventArgs e)
        {
            bool jaPossuiPonto = false;
            if (!(txtValores.Text.Length == 0))
            {
                foreach (char element in txtValores.Text)
                {
                    if (element == ',')
                    {
                        jaPossuiPonto = true;
                        break;
                    }
                }
                if (!jaPossuiPonto)
                {
                    txtValores.Text = txtValores.Text + ",";
                }
            }
            else { txtValores.Text = "0,"; }
        }

        private void btnZerar_Click(object sender, EventArgs e)
        {
            CalularValores.setResultado(0);
            txtValores.Text = "";
            lblResultado.Text = Convert.ToString(CalularValores.getResultado());
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            op = "su";
            if (txtValores.Text != "")
            {
                CalularValores.setResultado(Convert.ToDouble(txtValores.Text));
                txtValores.Text = "";
                lblResultado.Text = Convert.ToString(CalularValores.getResultado());
            }
            else
            {
                executarCalculo();
                lblResultado.Text = Convert.ToString(CalularValores.getResultado());
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (op != "" && txtValores.Text != "") { executarCalculo(); }
            
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            op = "mu";
            if (txtValores.Text != "")
            {
                CalularValores.setResultado(Convert.ToDouble(txtValores.Text));
                txtValores.Text = "";
                lblResultado.Text =  Convert.ToString(CalularValores.getResultado());
            }
            else
            {
                executarCalculo();
                lblResultado.Text = Convert.ToString(CalularValores.getResultado());
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            op = "di";
            if (txtValores.Text != "")
            {
                CalularValores.setResultado(Convert.ToDouble(txtValores.Text));
                txtValores.Text = "";
                lblResultado.Text = Convert.ToString(CalularValores.getResultado());
            }
            else
            {
                executarCalculo();
                lblResultado.Text = Convert.ToString(CalularValores.getResultado());
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
