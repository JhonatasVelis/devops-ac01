﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    public class CalularValores
    {
        private static double? resultado = 0;
        public double? valor2 { get; private set; }
        public string operacao { get; private set; }

        public CalularValores( double? valor2, string operacao)
        {
            this.valor2 = valor2;
        }

        public static double? getResultado() { return resultado; }
        public static void setResultado(double? valor) { resultado = valor; }
    }
}
