from infra.db import con
from wrap_connection import transact 
from model.aluno import Aluno

sql_criar = "INSERT INTO PEDIDO(nome, CEP,RUA,BAIRRO,NUMERO,EMAIL,TELEFONE,SABORPIZZA,QUANTIDADE_PIZZA,FORMA_PAGAMENTO,VALOR_TOTAL) VALUES(?,?,?,?,?,?,?,?,?,?,?)"
sql_listar = "SELECT * FROM PEDIDO"
sql_localizar = "SELECT id, nome FROM Aluno WHERE id = ?"
sql_delete  = "DELETE FROM Aluno WHERE id = ?"
sql_atualizar = "UPDATE Aluno SET id = ?, nome = ? WHERE id = ?"

alunos_db = []

class AlunoJaExiste(Exception):
    pass

@transact(con)
def listar():
    cursor.execute(sql_listar)
    resultado = []
    for r in cursor.fetchall():
        resultado.append(Aluno(r[0], r[1]))
    return resultado

@transact(con)
def localizar(id):
    cursor.execute(sql_localizar, (id,))
    r = cursor.fetchone()
    if r == None:
        return None
    return Aluno(r[0], r[1])

@transact(con)
def criar(pedido):
    cursor.execute(sql_criar, (pedido.nome,pedido.cpf,pedido.cep, pedido.rua,pedido.bairro,pedido.numero,pedido.email,pedido.telefone,pedido.saborpizza,pedido.quantidadePizza,pedido.formaPagamento,pedido.valorTotal))
    connection.commit()

@transact(con)
def remover(id):
    cursor.execute(sql_delete, (id,))
    connection.commit()

@transact(con)
def atualizar(id_antigo, id_novo, nome):
    cursor.execute(sql_atualizar, (id_novo, nome, id_antigo))
    connection.commit()


