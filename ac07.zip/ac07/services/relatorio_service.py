from model.relatorio import ItemRelatorio

def relatorio():
    from services.solicitacao_matricula_service import listar as listar_s_matriculas
    from services.aluno_service import localizar as localizar_aluno
    from services.professor_service import localizar as localizar_professor
    from services.disciplina_service import localizar as localizar_disciplina
    from services.disciplina_ofertada_service import localizar as localizar_disc_ofertada

    resultado = []

    for sm in listar_s_matriculas():
        dof = localizar_disc_ofertada(sm.id_disciplina_ofertada)
        professor = localizar_professor(dof.id_professor)
        disciplina = localizar_disciplina(dof.id_disciplina)
        aluno = localizar_aluno(sm.id_aluno)
        item = ItemRelatorio(aluno.nome,disciplina.nome,professor.nome,dof.turma,dof.ano,dof.semestre)
        resultado.append(item)
    return resultado