from model.solicitacao_matricula import SolicitacaoMatricula 
from infra.log import Log
from dao.solicitacao_matricula_dao import \
    listar as listar_dao, \
    localizar as localizar_dao, \
    criar as criar_dao, \
    remover as remover_dao, \
    atualizar as atualizar_dao

solicitacao_matricula_db = []


class JaExiste(Exception):
    pass


class NaoExiste(Exception):
    pass

class StatusInvalido(Exception):
    pass

class DataInvalida(Exception):
    pass

def validar_data(sdata):
    import datetime

    try:
        print("Validando " + sdata)
        data = datetime.datetime.strptime(sdata, "%Y/%m/%d")
    except:
        print("Não deu")
        return False
    else:
        print("Aceito")
        return True

def status_ok(status):
    return status in range(1,7)

def listar():
    return listar_dao()

def localizar(id_som):
    return localizar_dao(id_som)

def criar(id_som, id_aluno, id_disciplina_ofertada, dt_solicitacao, id_coordenador, status):
    from services.aluno_service import localizar as localizar_aluno
    from services.professor_service import localizar as localizar_coordenador
    from services.disciplina_ofertada_service import localizar as localizar_discplina_ofertada

    if localizar(id_som) != None:
        raise JaExiste()

    if not validar_data(dt_solicitacao):
        raise DataInvalida()

    if not status_ok(status):
        raise StatusInvalido()

    if localizar_coordenador(id_coordenador) == None:
        raise NaoExiste()

    if localizar_aluno(id_aluno) == None:
        raise NaoExiste()   

    if localizar_discplina_ofertada(id_disciplina_ofertada) == None:
        raise NaoExiste()   

    log = Log(None)
    criado = SolicitacaoMatricula(id_som, id_aluno, id_disciplina_ofertada, dt_solicitacao, id_coordenador, status)
    criar_dao(criado)
    log.finalizar(criado)
    return criado

def remover(id_som):
    existente = localizar(id_som)
    if existente == None:
        return None
    log = Log(existente)
    remover_dao(existente.id_som)
    log.finalizar(None)
    return existente

def atualizar(id_antigo, id_som, id_aluno, id_disciplina_ofertada, dt_solicitacao, id_coordenador, status):
    from services.professor_service import localizar as localizar_coordenador
    from services.aluno_service import localizar as localizar_aluno
    from services.disciplina_ofertada_service import localizar as localizar_discplina_ofertada
    
    existente = localizar(id_antigo)
    if existente == None:
        return None
    if id_antigo != id_som:
        colisao = localizar(id_som)
        if colisao != None:
            raise SolicitacaoMatriculaJaExiste
    if not status_ok(status):
        raise StatusInvalido()
    if localizar_coordenador(id_coordenador) == None:
        raise NaoExiste()
    if localizar_aluno(id_aluno) == None:
        raise NaoExiste()   
    if localizar_discplina_ofertada(id_disciplina_ofertada) == None:
        raise NaoExiste()
    log = Log(existente)
    atualizar_dao(id_antigo,id_som, id_aluno, id_disciplina_ofertada, dt_solicitacao, id_coordenador, status)
    log.finalizar(existente)
    return existente

