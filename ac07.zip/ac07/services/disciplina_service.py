from model.disciplina import Disciplina
from infra.log import Log
from dao.disciplina_dao import \
    listar as listar_dao, \
    localizar as localizar_dao, \
    criar as criar_dao, \
    remover as remover_dao, \
    atualizar as atualizar_dao 

disciplina_db = [] 


class JaExiste(Exception):
    pass

class StatusInvalido(Exception):
    pass

class NaoExiste(Exception):
    pass

def status_ok(status):
    return status in range(0,2)

def listar():
    return listar_dao()

def localizar(id):
    return localizar_dao(id)

def criar(id, nome, status, plano_ensino, carga_horaria, id_coordenador):
    from services.coordenador_service import localizar as localizar_coorde
    if localizar(id) != None:
        raise JaExiste()
    if not status_ok(status):
        raise StatusInvalido()
    if localizar_coorde(id_coordenador) == None:
        raise NaoExiste()
    log = Log(None)
    criado = Disciplina(id, nome, status, plano_ensino, carga_horaria, id_coordenador)
    criar_dao(criado)
    log.finalizar(criado)
    return criado

def remover(id):
    existente = localizar(id)
    if existente == None:
        return None
    log = Log(existente)
    remover_dao(existente.id)
    log.finalizar(None)
    return existente

def atualizar(id_antigo, id_novo, nome, status, plano_ensino, carga_horaria, id_coordenador):
    from services.coordenador_service import localizar as localizar_coorde
    
    existente = localizar(id_antigo)
    if existente == None:
        return None
    if id_antigo != id_novo:
        colisao = localizar(id_novo)
        if colisao != None:
            raise JaExiste
    if not status_ok(status):
        raise StatusInvalido()
    if localizar_coorde(id_coordenador) == None:
        raise NaoExiste()
    log = Log(existente)
    atualizar_dao(id_antigo,id_novo, nome, status, plano_ensino, carga_horaria, id_coordenador)
    log.finalizar(existente)
    return existente

