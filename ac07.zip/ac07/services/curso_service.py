from model.curso import Curso
from infra.log import Log

from dao.curso_dao import \
    listar as listar_dao, \
    localizar as localizar_dao, \
    criar as criar_dao, \
    atualizar as atualizar_dao, \
    remover as remover_dao

cursos_db = []

class CursoJaExiste(Exception):
    pass

def listar():
    return listar_dao()

def localizar(id):
    return localizar_dao(id)

def criar(id, nome):
    if localizar(id) != None:
        raise CursoJaExiste()
    log = Log(None)
    criado = Curso(id, nome)
    criar_dao(criado)
    log.finalizar(criado)
    return criado

def remover(id):
    existente = localizar(id)
    if existente == None:
        return None
    log = Log(existente)
    remover_dao(existente.id)
    log.finalizar(None)
    return existente

def atualizar(id_antigo, id_novo, nome):
    existente = localizar(id_antigo)
    if existente == None:
        return None
    if id_antigo != id_novo:
        colisao = localizar(id_novo)
        if colisao != None:
            raise CursoJaExiste()
    log = Log(existente)
    atualizar_dao(id_antigo,id_novo,nome)
    log.finalizar(existente)
    return existente

