from model.disciplina_ofertada import DisciplinaOfertada
from infra.log import Log


from dao.disciplina_ofertada_dao import \
    listar as listar_dao, \
    localizar as localizar_dao, \
    criar as criar_dao, \
    remover as remover_dao, \
    atualizar as atualizar_dao

disciplina_ofertada_db = []


class JaExiste(Exception):
    pass

class NaoExiste(Exception):
    pass

class DataInvalida(Exception):
    pass

def validar_data(sdata):
    import datetime

    try:
        print("Validando " + sdata)
        data = datetime.datetime.strptime(sdata, "%Y/%m/%d")
    except:
        print("Não deu")
        return False
    else:
        print("Aceito")
        return True

def listar():
    return listar_dao()

def localizar(id):
    return localizar_dao(id)

def localizar_colisao(id, id_disciplina, ano, semestre, turma, id_curso):
    for x in disciplina_ofertada_db:
        if x.id != id and \
                x.id_disciplina == id_disciplina and \
                x.ano ==  ano and \
                x.semestre == semestre and \
                x.turma == turma and \
                x.id_curso == id_curso:
            return x
    return None

def criar(id, id_disciplina, id_professor, ano, semestre, turma, id_curso, data):
    from services.professor_service import localizar as localizar_professor
    from services.disciplina_service import localizar as localizar_disciplina
    from services.curso_service import localizar as localizar_curso

    if not validar_data(data):
        raise DataInvalida()

    if localizar(id) != None:
        raise JaExiste()

    if localizar_colisao(id, id_disciplina, ano, semestre, turma, id_curso):
        raise JaExiste()

    if localizar_professor(id_professor) == None:
        raise NaoExiste()
    
    if localizar_disciplina(id_disciplina) == None:
        return NaoExiste()
    
    if localizar_curso(id_curso) == None:
        return NaoExiste()

    log = Log(None)
    criado = DisciplinaOfertada(id, id_disciplina, id_professor, ano, semestre, turma, id_curso, data)
    criar_dao(criado)
    log.finalizar(criado)
    return criado

def remover(id):
    existente = localizar(id)
    if existente == None:
        return None
    log = Log(existente)
    remover_dao(existente.id)
    log.finalizar(None)
    return existente

def atualizar(id_antigo, id_novo, id_disciplina, id_professor, ano, semestre, turma, id_curso, data):
    from services.professor_service import localizar as localizar_professor
    from services.disciplina_service import localizar as localizar_disciplina
    from services.curso_service import localizar as localizar_curso

    if not validar_data(data):
        raise DataInvalida()
    existente = localizar(id_antigo)
    if existente == None:
        return None
    if id_antigo != id_novo:
        colisao = localizar(id_novo)
        if colisao != None:
            raise JaExiste()
    if localizar_colisao(id_antigo, id_disciplina, ano, semestre, turma, id_curso):
        raise JaExiste()
    if localizar_disciplina(id_disciplina) == None:
        raise NaoExiste()
    if localizar_professor(id_professor) == None:
        raise NaoExiste()
    if localizar_curso(id_curso) == None:
        raise NaoExiste()
    log = Log(existente)
    atualizar_dao(id_antigo,id_novo, id_disciplina, id_professor, ano, semestre, turma, id_curso, data)
    log.finalizar(existente)
    return existente

